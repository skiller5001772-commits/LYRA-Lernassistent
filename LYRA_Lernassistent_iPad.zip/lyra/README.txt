LYRA – persönlicher KI-Lernassistent
Version 1: hochwertige iPad-taugliche Web-App-Oberfläche.
Enthalten: Dashboard, Lernen, Normal, Vokabeln, Hausaufgaben, Klassenarbeiten (gesperrt), fester Klasse-10-Stoffplan und lokaler Fortschritt.
Die echte KI-API ist bewusst noch nicht im Browser hinterlegt. Dafür sollte ein Backend verwendet werden, damit kein API-Schlüssel im iPad-Browser liegt.
Auf dem iPad: index.html über einen Webserver öffnen und im Browser „Zum Home-Bildschirm“ verwenden.
